package com.example.juanmuniz.u3_a14juanms;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.app.AlertDialog;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class U3_a14juanms extends FragmentActivity {


    private DialogoFragment dialogoFragmento;//Dialogo con dialogfragment
    private static final int dialogo = 1;
    private Button botonMulti;
    private Button botonDatos;
    private final static int COD_ActPrin= 5;//codigo co que se chama a actividade 2
    AlertDialog.Builder venta;//variable para o diálogo
    private TextView verPhone;
    private TextView verCadea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal_u3_b_a14juanms);

        botonMulti=(Button) findViewById(R.id.botonDTB);
        botonDatos=(Button) findViewById(R.id.botonDatos);
        verPhone=(TextView)findViewById(R.id.telefono_invisible);
        verCadea = (TextView) findViewById(R.id.cadea_invisible);
        dialogoFragmento = new DialogoFragment();


        botonMulti.setOnLongClickListener(new View.OnLongClickListener() {//Listener para o longclick
            @Override
            public boolean onLongClick(View v) {
                // TODO Auto-generated method stub
                FragmentManager fm = getSupportFragmentManager();
                //facemos o necesario para pasarlle ó dialogo os datos
                Bundle feixe =new Bundle();
                feixe.putString("Texto",verCadea.getText().toString());
                feixe.putString("Telefono",verPhone.getText().toString());
                dialogoFragmento.setArguments(feixe);
                dialogoFragmento.show(fm, "Escolle unha opción");
                return true;
            }
        });//onLongClickListener
    }//onCreate




    public void mostraDatos(View v){
        //mostramos los datos si ya los hay o sacamos un toast de aviso de que faltan datos
        if((! verCadea.getText().toString().equals("")) && (! verPhone.getText().toString().equals(""))) {
            Toast.makeText(getApplicationContext(), verCadea.getText() + "\n" + verPhone.getText(), Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "Faltan datos", Toast.LENGTH_SHORT).show();
        }
    }//Mostrar datos en el boton DATOS, hay onClick en el layout




    //volver del activity secundaria y poner los textviews ocultos con sus valores
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COD_ActPrin)
            if (resultCode == RESULT_OK) {
                if(data.hasExtra("Texto") || data.hasExtra("Telefono")) {
                    //Se escribe en los

                        verCadea.setText(data.getExtras().getString("Texto"));
                        verPhone.setText(data.getExtras().getString("Telefono"));

                }else{
                    Toast.makeText(U3_a14juanms.this, "faltan datos", Toast.LENGTH_SHORT).show();
                }
            }
        }





    public void llamarAct2(View v){
        Intent intent=new Intent(this,Activity_secundaria_U3.class);
        startActivityForResult(intent, COD_ActPrin);
    }// chamar a actividade dous



    @Override
    protected void onSaveInstanceState(Bundle estado) {
        super.onSaveInstanceState(estado);
        estado.putString("Telefono", verPhone.getText().toString());
        estado.putString("Texto", verCadea.getText().toString());
        //Destruyo el dialogo
        this.removeDialog(1);

    }//on Save


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        verPhone.setText(savedInstanceState.getString("Telefono"));
        verCadea.setText(savedInstanceState.getString("Texto"));


    }//Restored







    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_u3_a14juanms, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
