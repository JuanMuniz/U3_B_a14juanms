package com.example.juanmuniz.u3_a14juanms;


import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class DialogoFragment extends DialogFragment{

    private Button botonBusqueda;
    private Button botonTelefono;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {


        //Recibimos os datos en duas variables tipo string
        final String verPhone = getArguments().getString("Telefono");
        final String verCadea = getArguments().getString("Texto");
        final View rootView = inflater.inflate(R.layout.dialogo, container, false);
        getDialog().setTitle(getTag());  // O Tag se envía dende a activiy có método show.
        botonBusqueda = (Button) rootView.findViewById(R.id.busqueda);
        botonTelefono = (Button) rootView.findViewById(R.id.telefono);
        //Listener del web search
        botonBusqueda.setOnClickListener(new OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    String busqueda = getResources().getString(R.string.busquedaXdefecto);

                    if (!verCadea.equals("")) {
                        busqueda = verCadea;
                    }
                    //Creamos un intent para lanzar el buscador
                    Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                    intent.putExtra(SearchManager.QUERY, busqueda);
                    startActivity(intent);
                }//onClick

            });

        //Listener del telefono
        botonTelefono.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    //Si no hay telefono avisamos del error
                    if (!verPhone.equals("")) {
                        //Llamamos si hay un telefono
                        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + verPhone));
                        startActivity(intent);
                    } else {
                        Toast.makeText(getActivity(), getResources().getString(R.string.sinTelefono), Toast.LENGTH_SHORT).show();
                    }
                }
            });

        // Do something else
        return rootView;
    }
}
