package com.example.juanmuniz.u3_a14juanms;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Activity_secundaria_U3 extends Activity {

    Button botonPechar;
    EditText textoPhone;
    EditText textoCadea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secundaria__u3_b);
        botonPechar=(Button)findViewById(R.id.btnPechar);
        textoPhone=(EditText)findViewById(R.id.telefono);
        textoCadea=(EditText)findViewById(R.id.cadea);
    }//onCreate

   //cerrar y mandar los datos de los TextViews
    public void cerrarSec(View v){
        Intent intent = new Intent();
        intent.putExtra("Texto", textoCadea.getText().toString());
        intent.putExtra("Telefono", textoPhone.getText().toString());
        setResult(RESULT_OK, intent);
        finish();
    }//cerrarSec


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_activity_secundaria__u3, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
