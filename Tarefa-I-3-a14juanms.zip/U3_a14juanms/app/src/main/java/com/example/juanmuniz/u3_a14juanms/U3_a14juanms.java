package com.example.juanmuniz.u3_a14juanms;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class U3_a14juanms extends Activity {
    private static final int dialogo = 1;
    private Button botonMulti;
    private Button botonDatos;
    private final static int COD_ActPrin= 5;//codigo co que se chama a actividade 2
    AlertDialog.Builder venta;//variable para o diálogo
    private TextView verPhone;
    private TextView verCadea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_u3_a14juanms);

        botonMulti=(Button) findViewById(R.id.botonDTB);
        botonDatos=(Button) findViewById(R.id.botonDatos);
        verPhone=(TextView)findViewById(R.id.telefono_invisible);
        verCadea= (TextView) findViewById(R.id.cadea_invisible);

        botonMulti.setOnLongClickListener(new View.OnLongClickListener() {//Listener para o longclick
            @Override
            public boolean onLongClick(View v) {
                // TODO Auto-generated method stub
                showDialog(dialogo);
                return true;
            }
        });//onLongClickListener
    }//onCreate

    protected Dialog onCreateDialog(int id) {

        venta = new AlertDialog.Builder(this);
        venta.setIcon(android.R.drawable.ic_dialog_info);
        venta.setTitle("Cadro de diálogo");
        venta.setMessage("Escolle unha opción");
        venta.setCancelable(false);
        venta.setPositiveButton("Marcar Teléfono", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {

                if (!verPhone.getText().toString().equals("")) {
                    //Llamamos si hay un telefono
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + verPhone.getText().toString()));
                    startActivity(intent);
                } else {
                    //Si no hay telefono avisamos del error
                    Toast.makeText(U3_a14juanms.this, getResources().getString(R.string.sinTelefono), Toast.LENGTH_SHORT).show();
                }
            }

        });

        venta.setNegativeButton("Buscar en google", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int boton) {
                String busqueda = getResources().getString(R.string.busquedaXdefecto);

                if (!verCadea.getText().toString().equals("")) {
                    busqueda = verCadea.getText().toString();
                }
                //Creamos un intent para lanzar el buscador
                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                intent.putExtra(SearchManager.QUERY, busqueda);
                startActivity(intent);
            }//onClick
        });

        return venta.create();


    }//dialog

    public void mostraDatos(View v){
        //mostramos los datos si ya los hay o sacamos un toast de aviso de que faltan datos
        if((! verCadea.getText().toString().equals("")) && (! verPhone.getText().toString().equals(""))) {
            Toast.makeText(getApplicationContext(), verCadea.getText() + "\n" + verPhone.getText(), Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(), "Faltan datos", Toast.LENGTH_SHORT).show();
        }
    }//Mostrar datos en el boton DATOS, hay onClick en el layout




    //volver del activity secundaria y poner los textviews ocultos con sus valores
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COD_ActPrin)
            if (resultCode == RESULT_OK) {
                if(data.hasExtra("Texto") || data.hasExtra("Telefono")) {
                    //Se escribe en los

                        verCadea.setText(data.getExtras().getString("Texto"));
                        verPhone.setText(data.getExtras().getString("Telefono"));

                }else{
                    Toast.makeText(U3_a14juanms.this, "faltan datos", Toast.LENGTH_SHORT).show();
                }
            }
        }





    public void llamarAct2(View v){
        Intent intent=new Intent(this,Activity_secundaria_U3.class);
        startActivityForResult(intent, COD_ActPrin);
    }// chamar a actividade dous



    @Override
    protected void onSaveInstanceState(Bundle estado) {
        super.onSaveInstanceState(estado);
        estado.putString("Telefono", verPhone.getText().toString());
        estado.putString("Texto", verCadea.getText().toString());
        //Destruyo el dialogo
        this.removeDialog(1);

    }//on Save


    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        verPhone.setText(savedInstanceState.getString("Telefono"));
        verCadea.setText(savedInstanceState.getString("Texto"));


    }//Restored







    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_u3_a14juanms, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
